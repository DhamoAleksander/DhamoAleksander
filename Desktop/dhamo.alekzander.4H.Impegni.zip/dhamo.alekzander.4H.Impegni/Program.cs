﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dhamo.alekzander._4H.Impegni
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Impegni> impegni = new List<Impegni>();
            Impegni var = new Impegni();
            bool exit=false;
            while(exit==false)
            {
                Console.WriteLine("\n 1- Aggiungi impegno\n2- Stampa impegni conclusi\n3- Stampa impegni il cui stato di avanzamento è superiore ad una certa percentuale\n4- Modificare lo stato di avanzamento di un impegno\n5- Stampare gli impegni più vecchi di una certa data \n6- Esci\n");
                int scelta = Convert.ToInt32(Console.ReadLine());
                switch (scelta)
                {
                    case 1:
                        string impegno = "";
                        Console.WriteLine("Inserire il nome di chi deve svolgere l'impegno: ");
                        impegno = Console.ReadLine();
                        Console.WriteLine("Inserire la mansione: ");
                        impegno = impegno + ";" + Console.ReadLine();
                        Console.WriteLine("Inserire la descrizione mansione: ");
                        impegno = impegno + ";" + Console.ReadLine();
                        Console.WriteLine("Inserire la durata: ");
                        impegno = impegno + ";" + Console.ReadLine();
                        impegni.Add(new Impegni(impegno));
                        break;
                    case 2:
                        for (int i = 0; i < impegni.Count; i++)
                        {
                            if (impegni[i].ImpegniConclusi() == true)
                            {
                                Console.WriteLine($"Numero impegno concluso: {i + 1}, la mansione era: {impegni[i].MansioneConclusa()}");
                            }
                        }
                        break;

                    case 3:
                        Console.WriteLine("Inserire la percentuale che vuole verificare: ");
                        int percentuale = Convert.ToInt32(Console.ReadLine());
                        for (int i = 0; i < impegni.Count; i++)
                        {
                            if (impegni[i].VerificaStato(percentuale) == true)
                            {
                                Console.WriteLine($"Numero impegno con una percentuale più alta: {i + 1}, la mansione è: {impegni[i].MansioneConclusa()}");
                            }
                        }
                        break;

                    case 4:
                        Console.WriteLine("Inserire il numero dell'impegno al quale vuole modificare lo stato di avanzamento");
                        int idx = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Inserire il nuovo lo stato di avanzamento");
                        impegni[idx-1].NuovoStato(Convert.ToInt32(Console.ReadLine()));
                        break;

                    case 5:
                        Console.WriteLine("Inserire la data che vuole verificare. Formato input: anno,mese,giorno");
                        DateTime data = Convert.ToDateTime(Console.ReadLine());
                        for (int i = 0; i < impegni.Count; i++)
                        {
                            if (impegni[i].VerificaData(data) == true)
                            {
                                Console.WriteLine($"Numero impegno con una data più vecchia: {i + 1}, la mansione è: {impegni[i].MansioneConclusa()}");
                            }
                        }
                        break;

                    case 6:
                        exit = true;
                        break;
                }
            }
            
            Console.ReadKey();
        }
    }
}
