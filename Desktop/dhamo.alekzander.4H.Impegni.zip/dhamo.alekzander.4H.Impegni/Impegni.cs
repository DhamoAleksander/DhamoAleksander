﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dhamo.alekzander._4H.Impegni
{
    public class Impegni
    {
        private string nomeDipendente;
        private string mansione;
        private string descrizioneAttivita;
        private int durataOre;
        private DateTime dataInizio= new DateTime();
        private int statoAvanzamento;

        public Impegni()
        {
            nomeDipendente = "";
            mansione = "";
            descrizioneAttivita = "";
            durataOre = 0;
            dataInizio = new DateTime(2020, 1, 1);
            statoAvanzamento = 0;
        }

        public Impegni(string var)
        {
            string[] impegno = var.Split(';');
            nomeDipendente = impegno[0];
            mansione = impegno[1];
            descrizioneAttivita = impegno[2];
            durataOre = Convert.ToInt32(impegno[3]);
            dataInizio = DateTime.Now;
            statoAvanzamento = 15;
        }

        public bool ImpegniConclusi()
        {
            bool concluso = false;
            if(statoAvanzamento==100)
            {
                concluso = true;
            }
            return concluso;
        }

        public string MansioneConclusa()
        {
            string nome = mansione;
            return nome;
        }

        public bool VerificaStato(int percentuale)
        {
            bool concluso = false;
            if (statoAvanzamento > percentuale)
            {
                concluso = true;
            }
            return concluso;
        }

        public bool VerificaData(DateTime data)
        {
            bool vecchia = false;
            if (dataInizio<data)
            {
                vecchia = true;
            }
            return vecchia;
        }

        public void NuovoStato(int stato)
        {
            statoAvanzamento = stato;
        }
    }
}
